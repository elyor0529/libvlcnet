README for the VLC media player
===============================

The VideoLAN web site . . . http://www.videolan.org/
Documentation . . . . . . . http://www.videolan.org/doc/
Support . . . . . . . . . . http://www.videolan.org/support/
Forums  . . . . . . . . . . http://forum.videolan.org/
Wiki  . . . . . . . . . . . http://wiki.videolan.org/
The Developers site . . . . http://www.videolan.org/developers/vlc.html

ABOUT-NLS          - Notes on the Free Translation Project.
AUTHORS            - Main VLC authors.
COPYING            - The GPL license.
ChangeLog          - The VLC ChangeLog.
HACKING            - Hacking VLC.
INSTALL            - Installation instructions.
INSTALL.win32      - Installation instructions for the Win32 version of VLC.
NEWS               - Important modifications between the releases.
README             - This file.
THANKS             - All VLC contributors.
bindings/          - Bindings around LibVLC.
extras/analyser    - Code analyser and editor specific files.
extras/buildsystem - different buildsystems specific files.
extras/contrib     - external libraries retrieving facilities for systems that
                     don't have package manager.
extras/deprecated  - Now deprecated files.
extras/misc        - Files that don't fit in the other extras/ categories.
extras/package     - VLC packaging specific files such as spec files.
include/           - Include files
doc/               - Miscellaneous documentation.
libs/              - libraries that we host.
po/                - languages related files.
projects/          - projects that uses libVLC such as the web browsers plugin.
share/             - Common Resources files.
src/               - VLC and libvlc source code.
